<?php
include '../connect.php'; // Database connection

// When the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit'])) {
        $package_id = intval($_POST['package_id']);
        $titles = $_POST['title'];
        $descriptions = $_POST['description'];
        $itineraries = $_POST['itinerary']; // Itinerary details for each image

        $target_dir = $_SERVER['DOCUMENT_ROOT'] . "/new_traing/admin/images/";
        $upload_ok = 1;
        $max_files = 5;

        $success_count = 0; // Count successful uploads
        $errors = []; // Collect error messages

        for ($i = 0; $i < $max_files; $i++) {
            // Only process image upload if the image file is provided
            if (isset($_FILES["image"]["name"][$i]) && $_FILES["image"]["name"][$i] != '') {
                $file_name = basename($_FILES["image"]["name"][$i]);
                $target_file = $target_dir . uniqid() . '_' . $file_name;
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

                if (getimagesize($_FILES["image"]["tmp_name"][$i]) === false) {
                    $errors[] = "File $file_name is not an image.";
                    $upload_ok = 0;
                }

                if ($_FILES["image"]["size"][$i] > 5000000) {
                    $errors[] = "File $file_name is too large.";
                    $upload_ok = 0;
                }

                if (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
                    $errors[] = "File $file_name has an invalid format.";
                    $upload_ok = 0;
                }

                if ($upload_ok) {
                    if (move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file)) {
                        $sql = "UPDATE package_images SET image_url = ?, title = ?, description = ?, itinerary = ? WHERE id = ?";
                        if ($stmt = $conn->prepare($sql)) {
                            $stmt->bind_param("ssssi", $target_file, $titles[$i], $descriptions[$i], $itineraries[$i], $_POST['image_id'][$i]);
                            if ($stmt->execute()) {
                                $success_count++;
                            } else {
                                $errors[] = "Database error for file $file_name.";
                            }
                        } else {
                            $errors[] = "Query preparation error for file $file_name.";
                        }
                    } else {
                        $errors[] = "Error uploading file $file_name.";
                    }
                }
            } else {
                // If no file is uploaded, update only the text fields
                $sql = "UPDATE package_images SET title = ?, description = ?, itinerary = ? WHERE id = ?";
                if ($stmt = $conn->prepare($sql)) {
                    $stmt->bind_param("sssi", $titles[$i], $descriptions[$i], $itineraries[$i], $_POST['image_id'][$i]);
                    if ($stmt->execute()) {
                        $success_count++;
                    } else {
                        $errors[] = "Database error for image ID " . $_POST['image_id'][$i];
                    }
                } else {
                    $errors[] = "Query preparation error for image ID " . $_POST['image_id'][$i];
                }
            }
        }

        // Display a summary message
        echo "<strong>Upload Summary:</strong><br>";
        echo "Successfully uploaded $success_count file(s).<br>";
        if (!empty($errors)) {
            echo "Errors encountered:<br>";
            foreach ($errors as $error) {
                echo "- $error<br>";
            }
        }
    }
}

// If the form is not submitted, get images for the selected package
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['package_id'])) {
    $package_id = $_GET['package_id'];
    $images = [];

    // Get images and details for the selected package
    $sql = "SELECT id, image_url, title, description, itinerary FROM package_images WHERE package_id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $package_id);
        $stmt->execute();
        $stmt->store_result();
        
        // Ensure the number of variables matches the number of columns returned
        $stmt->bind_result($image_id, $image_url, $title, $description, $itinerary);
        
        while ($stmt->fetch()) {
            $images[] = [
                'id' => $image_id,
                'image_url' => $image_url,
                'title' => $title,
                'description' => $description,
                'itinerary' => $itinerary
            ];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Slider Images for Package</title>
</head>
<body>
<h2>Edit Slider Images for Package</h2>
<form action="edit-package-slider.php" method="GET">
    <label for="package_id">Select Package:</label>
    <select name="package_id" required>
        <option value="">Select Package</option>
        <?php
        // Fetch available packages from the database
        $result = $conn->query("SELECT package_id, package_name FROM packages_overview");
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $selected = (isset($_GET['package_id']) && $_GET['package_id'] == $row['package_id']) ? 'selected' : '';
                echo "<option value='{$row['package_id']}' $selected>{$row['package_name']}</option>";
            }
        } else {
            echo "<option value=''>No packages available</option>";
        }
        ?>
    </select>
    <button type="submit">Load Package</button>
</form>


    <?php if (isset($images) && !empty($images)): ?>
        <h3>Existing Images for Package</h3>
        <form action="edit-package-slider.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="package_id" value="<?php echo $package_id; ?>">

            <?php foreach ($images as $index => $image): ?>
                <h4>Image <?php echo $index + 1; ?></h4>
                <input type="hidden" name="image_id[]" value="<?php echo $image['id']; ?>">
                <label for="image_<?php echo $index; ?>">Select Image:</label>
                <input type="file" name="image[]" id="image_<?php echo $index; ?>"><br><br>
                <label for="title_<?php echo $index; ?>">Image Title:</label>
                <input type="text" name="title[]" id="title_<?php echo $index; ?>" value="<?php echo htmlspecialchars($image['title']); ?>"><br><br>
                <label for="description_<?php echo $index; ?>">Image Description:</label>
                <textarea name="description[]" id="description_<?php echo $index; ?>"><?php echo htmlspecialchars($image['description']); ?></textarea><br><br>

                <!-- Itinerary Field for Each Image -->
                <label for="itinerary_<?php echo $index; ?>">Itinerary for Image:</label>
                <textarea name="itinerary[]" id="itinerary_<?php echo $index; ?>" rows="3"><?php echo htmlspecialchars($image['itinerary']); ?></textarea><br><br>
            <?php endforeach; ?>

            <button type="submit" name="submit">Submit</button>
        </form>
    <?php else: ?>
        <p>No existing images for this package.</p>
    <?php endif; ?>
</body>
</html>
