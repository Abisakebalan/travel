<?php
include '../connect.php'; // Database connection

// Initialize variables to prevent "undefined variable" errors
$extra_description = "";
$specifications = "";
$existing_image_url = "";
$package_id = "";  // Initialize package_id
$detail_id = "";   // Initialize detail_id
$error_message = ""; // Variable for error message

// Fetch packages for the dropdown
$packages_sql = "SELECT package_id, package_name FROM packages_overview";
$packages_result = $conn->query($packages_sql);

// Check if the package_id is passed in the URL
if (isset($_GET['package_id'])) {
    $package_id = $_GET['package_id'];
    
    // Ensure that the package_id is an integer for security reasons
    $package_id = (int)$package_id;
    
    // Fetch the details of the selected package by package_id
    $sql = "SELECT * FROM package_details WHERE package_id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $package_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Fetch the existing package details
            $row = $result->fetch_assoc();
            $detail_id = $row['detail_id']; // Get the detail_id for editing
            $extra_description = $row['extra_description'];
            $specifications = $row['specifications'];
            $existing_image_url = $row['detail_image_url']; // Assuming the image URL is stored here
        } else {
            // No existing details found for this package_id
            $error_message = "No existing details for this package!";
        }
        $stmt->close();
    }
}

// Handle the form submission for editing package details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the POST data from the edit form
    if (isset($_POST['package_id']) && !empty($_POST['package_id'])) {
        $package_id = $_POST['package_id']; // Get selected package ID
        $extra_description = $_POST['extra_description'];
        $specifications = $_POST['specifications'];
        $image_url = $_FILES['detail_image_url']['name']; // File upload for image

        // Handle file upload
        if (!empty($image_url)) {
            $target_dir = "images/";
            $target_file = $target_dir . basename($_FILES["detail_image_url"]["name"]);
            move_uploaded_file($_FILES["detail_image_url"]["tmp_name"], $target_file);
        } else {
            // If no new image, use the existing image URL
            $image_url = $existing_image_url;
        }

        // Prepare the SQL query to update package details in the database
        $sql_update = "UPDATE package_details SET package_id = ?, extra_description = ?, specifications = ?, detail_image_url = ? WHERE detail_id = ?";
        if ($stmt = $conn->prepare($sql_update)) {
            $stmt->bind_param("isssi", $package_id, $extra_description, $specifications, $image_url, $detail_id);
            if ($stmt->execute()) {
                echo "Package details updated successfully!";
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        echo "No package selected!";
    }
}
?>

<!-- Package Selection Form -->
<form method="GET" action="edit-package-details.php" class="mb-4">
    <div class="form-group">
        <label for="package_id">Select a Package to Edit:</label>
        <select name="package_id" id="package_id" class="form-control" required onchange="this.form.submit();">
            <option value="">-- Select a Package --</option>
            <?php while ($row = $packages_result->fetch_assoc()): ?>
                <option value="<?= $row['package_id']; ?>" <?= (isset($_GET['package_id']) && $_GET['package_id'] == $row['package_id']) ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($row['package_name']); ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>
</form>

<!-- Edit Package Details Form -->
<?php if ($error_message): ?>
    <p><?php echo $error_message; ?></p>
<?php else: ?>
    <form id="packageDetailsForm" action="edit-package-details.php?package_id=<?php echo isset($_GET['package_id']) ? $_GET['package_id'] : ''; ?>" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="extra_description">Extra Description:</label>
            <textarea name="extra_description" class="form-control" required><?php echo htmlspecialchars($extra_description); ?></textarea>
        </div>

        <div class="form-group">
            <label for="specifications">Specifications:</label>
            <textarea name="specifications" class="form-control" required><?php echo htmlspecialchars($specifications); ?></textarea>
        </div>

        <div class="form-group">
            <label for="detail_image_url">Upload New Image (Optional):</label>
            <input type="file" name="detail_image_url" class="form-control">
        </div>
        
        <?php if ($existing_image_url): ?>
            <div class="form-group">
                <p>Current Image: <img src="images/<?php echo htmlspecialchars($existing_image_url); ?>" alt="Current Image" width="100"></p>
            </div>
        <?php endif; ?>

        <button type="submit" class="btn btn-primary">Update Package Details</button>
    </form>
<?php endif; ?>
